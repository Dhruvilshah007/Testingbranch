package ImportantJavaConcepts.LambdaExpression;


public interface AddInter {

    int sum(int a,int b);
}



