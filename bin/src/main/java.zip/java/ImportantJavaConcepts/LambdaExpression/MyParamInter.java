package ImportantJavaConcepts.LambdaExpression;

public interface MyParamInter {

    public void sayHello(String name,String surname,int age);
}
