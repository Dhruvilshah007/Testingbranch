package OopsConcepts.PolymorphismBasics;

/*
Method Overriding

A method defined in the superclass is inherited by its subclass and is used by the objects created by the subclass. However, there may be occasions when an object should respond to the same method but behave differently when that method is called, which means a method defined in the superclass is overridden. Overriding is achieved by defining a method in the subclass that has the same name, the same arguments, and the same return type as a method in the superclass. So, when the method is called, the method defined in the subclass invoked and executed instead of the one in the superclass.
 */


//same method name different class and extends parent class
class Shape
{
    void draw()
    {
        System.out.println("Mention shape here");
    }

    void  numberOfSides()
    {
        System.out.println("side = 0");
    }
}

class Circle extends Shape
{
    void draw()
    {
        System.out.println("CIRCLE ");
    }

    void numberOfSides()
    {
        System.out.println("side = 0 ");
    }
}

class Box extends Shape
{
    void draw()
    {
        System.out.println("BOX ");
    }

    void numberOfSides()
    {
        System.out.println("side= 6");
    }
}

class Triangle extends Shape
{
    void draw()
    {
        System.out.println("TRIANGLE ");
    }

    void numberOfSides()
    {
        System.out.println("side = 3 ");
    }
}
class methodOveriding {

    public static void main (String args[])
    {
        Circle c = new Circle();
        c.draw();
        c.numberOfSides();

        Box b = new Box();
        b.draw();
        b.numberOfSides();

        Triangle t = new Triangle();
        t.draw();
        t.numberOfSides();
    }
}
