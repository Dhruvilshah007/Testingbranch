package OopsConcepts.PolymorphismBasics;

/*
Polymorphism

Polymorphism is an important OOP concept; it means the ability to take many forms. For Example, an operation exhibits different behavior in different situations. The behavior depends on the type of data used in operation. For Example, in the operation of addition, the operation generates a sum for two numbers. If the operands are strings, then a third-string is produced by the operation by concatenation.

The figure below demonstrates that a single function name can be used to handle the different numbers and different types of arguments.
In polymorphism, objects having different internal structures can share the same external interface; it means that a class of operation may be accessed in the same manner even though actions with each operation may differ. Inheritance extensively uses the concept of polymorphism.

Polymorphism can be achieved in two ways:

Method Overloading

It is possible to create methods with the same name but different parameter lists and different definitions. This is called method overloading. Method overloading is required when objects are required to perform similar tasks but using different input parameters. When we call a method in an object, Java matches up the method name first and then the number and type of parameters to decide which definition to execute.
 */


//same method name different paramteers
class CircleArea
{
    double area(double x)
    {
        return 3.14 * x;
    }
}

class SquareArea
{
    int area(int x)
    {
        return x * x;
    }
}


class RectangleArea
{
    int area(int x, int y)
    {
        return x * y;
    }
}

class TriangleArea
{
    int area(int y, int x)
    {
        return (y * x)/2;
    }
}
public class MethodOverloading {
    public static void main(String args[])
    {
        CircleArea ca = new CircleArea();
        SquareArea sa = new SquareArea();
        RectangleArea ra = new RectangleArea();
        TriangleArea ta = new TriangleArea();

        System.out.println("Circle area = "+ ca.area(1));
        System.out.println("Square area = "+ sa.area(2));
        System.out.println("Rectangle area = "+ ra.area(3,4));
        System.out.println("Triangle area = "+ ta.area(6,3));
    }
}

/*
Dynamic Binding

Binding is the process of linking a procedure call to the code to be executed in response to the call. It means that the code associated with the given procedure call is not known until the time of the call at runtime. It is associated with inheritance and polymorphism.

Message Communication

Objects communicate with each other in OOPs The process of programming in case of OOP consists of the following:

    Creating classes defining objects and their behavior.
    Creating objects
    Establishing communication between objects.

 */