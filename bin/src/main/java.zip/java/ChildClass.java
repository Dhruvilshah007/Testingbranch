/*
public class ChildClass extends ParentClass {

    public static void main(String[] args) {

        ParentClass a=new ParentClass();
        a.run();
        a.sayHello();

    }
}
*/
